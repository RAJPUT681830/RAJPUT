# best_save_restricted_content_bot
# made by [๛MR๛R͜͡AJPUT๛](tg://openmessage?user_id=6874153886) 

 
# Deploy on heroku


<a href="https://dashboard.heroku.com/new?template=https://github.com/Adity012/save-bot-02">
     <img height="30px" src="https://img.shields.io/badge/Deploy%20To%20Heroku-blueviolet?style=for-the-badge&logo=heroku">
  </a>
