echo "starting Bot ~@mrrajput_King";
python3 -m main
